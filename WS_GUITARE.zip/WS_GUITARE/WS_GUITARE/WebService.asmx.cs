﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WS_GUITARE
{
    /// <summary>
    /// Description résumée de WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Pour autoriser l'appel de ce service Web depuis un script à l'aide d'ASP.NET AJAX, supprimez les marques de commentaire de la ligne suivante. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        C_BASE La_Base = new C_BASE();

        [WebMethod]
        public void Add_Guitare(string P_Nom, int P_idMicrophoneNeck, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare(P_Nom, P_idMicrophoneNeck, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Neck(string P_Nom, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Neck(P_Nom, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Centrale(string P_Nom, int P_idMicrophoneNeck, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Centrale(P_Nom, P_idMicrophoneNeck, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Bridge(string P_Nom, int P_idMicrophoneNeck, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Bridge(P_Nom, P_idMicrophoneNeck, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Client(string P_Nom, string P_Prenom, string P_Adresse, string P_MotDePasse, string P_Telephone, string P_Email)
        {
            La_Base.Add_Client(P_Nom, P_Prenom, P_Adresse, P_MotDePasse, P_Telephone, P_Email);
        }

        [WebMethod]
        public List<C_CLIENT> Login(string P_Email, string P_Password)
        {
            return La_Base.Login(P_Email, P_Password).ToList();
        }

        [WebMethod]
        public List<C_BOIS> Get_All_Bois()
        {
            return La_Base.Get_All_Bois().ToList();
        }

        [WebMethod]
        public List<C_VIBRATO> Get_All_Vibrato()
        {
            return La_Base.Get_All_Vibrato().ToList();
        }

        [WebMethod]
        public List<C_MICROPHONE> Get_All_Microphone()
        {
            return La_Base.Get_All_Microphone().ToList();
        }

        [WebMethod]
        public List<C_GUITARE> Get_Guitare_By_Client_Id(int P_Id)
        {
            return La_Base.Get_Guitare_By_Client_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_CLIENT> Get_Client_By_Id(int P_Id)
        {
            return La_Base.Get_Client_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_MICROPHONE> Get_Microphone_By_Id(int P_Id)
        {
            return La_Base.Get_Microphone_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_BOIS> Get_Bois_By_Id(int P_Id)
        {
            return La_Base.Get_Bois_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_VIBRATO> Get_Vibrato_By_Id(int P_Id)
        {
            return La_Base.Get_Vibrato_By_Id(P_Id).ToList();
        }
      
    }
}
