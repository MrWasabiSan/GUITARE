﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CLIENT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailCommande : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailCommande(string P_idMicrophone_Neck, string P_idMicrophone_Centrale, string P_idVibrato, string P_idMicrophone_Bridge, string P_idBois_Manche, string P_idBois_Corps, string P_idBois_Touche)
        {
            InitializeComponent();

            List<NS_WS.C_BOIS> Bois_Corps = new List<NS_WS.C_BOIS>();
            List<NS_WS.C_BOIS> Bois_Touche = new List<NS_WS.C_BOIS>();
            List<NS_WS.C_BOIS> Bois_Manche = new List<NS_WS.C_BOIS>();
            List<NS_WS.C_MICROPHONE> Micro_Neck = new List<NS_WS.C_MICROPHONE>();
            List<NS_WS.C_MICROPHONE> Micro_Centrale = new List<NS_WS.C_MICROPHONE>();
            List<NS_WS.C_MICROPHONE> Micro_Bridge = new List<NS_WS.C_MICROPHONE>();
            List<NS_WS.C_VIBRATO> Le_Vibrato = new List<NS_WS.C_VIBRATO>();

            foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_Microphone_By_Id(Int32.Parse(P_idMicrophone_Neck)))
            {
                Micro_Neck.Add(item);
            }

            foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_Microphone_By_Id(Int32.Parse(P_idMicrophone_Centrale)))
            {
                Micro_Centrale.Add(item);
            }

            foreach (NS_WS.C_VIBRATO item in Le_WS.Get_Vibrato_By_Id(Int32.Parse(P_idVibrato)))
            {
                Le_Vibrato.Add(item);
            }

            foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_Microphone_By_Id(Int32.Parse(P_idMicrophone_Bridge)))
            {
                Micro_Bridge.Add(item);
            }

            foreach (NS_WS.C_BOIS item in Le_WS.Get_Bois_By_Id(Int32.Parse(P_idBois_Manche)))
            {
                Bois_Manche.Add(item);
            }

            foreach (NS_WS.C_BOIS item in Le_WS.Get_Bois_By_Id(Int32.Parse(P_idBois_Corps)))
            {
                Bois_Corps.Add(item);
            }

            foreach (NS_WS.C_BOIS item in Le_WS.Get_Bois_By_Id(Int32.Parse(P_idBois_Touche)))
            {
                Bois_Touche.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                MicroNeck.ItemsSource = Micro_Neck;
            });

            Task.Factory.StartNew(() =>
            {
                MicroCentrale.ItemsSource = Micro_Centrale;
            });

            Task.Factory.StartNew(() =>
            {
                MicroBridge.ItemsSource = Micro_Bridge;
            });

            Task.Factory.StartNew(() =>
            {
                BoisTouche.ItemsSource = Bois_Touche;
            });

            Task.Factory.StartNew(() =>
            {
                BoisManche.ItemsSource = Bois_Manche;
            });

            Task.Factory.StartNew(() =>
            {
                BoisCorps.ItemsSource = Bois_Corps;
            });

            Task.Factory.StartNew(() =>
            {
                LeVibrato.ItemsSource = Le_Vibrato;
            });
        }
    }
}