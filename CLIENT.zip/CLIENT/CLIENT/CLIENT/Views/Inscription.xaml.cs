﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CLIENT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Inscription : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public Inscription()
        {
            InitializeComponent();
        }

        public void On_btnInscription_Click(object P_Sender, EventArgs P_Arg)
        {
            if(entNom.Text != "" && entPrenom.Text != "" && entAdresse.Text != "" && entEmail.Text != "" && entTelephone.Text != "" && entPasswordConfirm.Text != "" && entPassword.Text != "")
            {
                if(entPassword.Text == entPasswordConfirm.Text)
                {
                    Le_WS.Add_Client(entNom.Text, entPrenom.Text, entAdresse.Text, entPassword.Text, entTelephone.Text, entEmail.Text);
                }
                else
                {
                    DisplayAlert("ERREUR", "Les mots de passes ne correspondent pas !", "ok");
                }
            }
            else
            {
                DisplayAlert("ERREUR", "Vous devez remplir tous les champs !", "ok");
            }
        }
    }
}