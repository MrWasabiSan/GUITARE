﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CLIENT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MesCommandes : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public MesCommandes(int P_Id)
        {
            InitializeComponent();

            List<NS_WS.C_GUITARE> Ses_Guitares = new List<NS_WS.C_GUITARE>();
            List<NS_WS.C_GUITARE> Ses_Guitares_Fini = new List<NS_WS.C_GUITARE>();

            foreach (NS_WS.C_GUITARE item in Le_WS.Get_Guitare_By_Client_Id(P_Id))
            {
                Ses_Guitares.Add(item);
                Ses_Guitares_Fini.Add(item);
            }
            Ses_Guitares.RemoveAll(r => r.Etat == "Terminé");
            Ses_Guitares_Fini.RemoveAll(r => r.Etat == "En cours");

            Task.Factory.StartNew(() =>
            {
                ListesGuitares.ItemsSource = Ses_Guitares;
                ListesGuitaresFini.ItemsSource = Ses_Guitares_Fini;
            });
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_GUITARE;
            await Navigation.PushModalAsync(new DetailCommande(Convert.ToString(details.idMicrophone_Neck), Convert.ToString(details.idMicrophone_Centrale), Convert.ToString(details.idVibrato), Convert.ToString(details.idMicrophone_Bridge), Convert.ToString(details.idBois_Manche), Convert.ToString(details.idBois_Corps), Convert.ToString(details.idBois_Touche)));
        }
    }
}